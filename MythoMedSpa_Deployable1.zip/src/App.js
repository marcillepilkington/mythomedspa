import { Flower, DoorOpen, ScrollText, RotateCcw, Leaf, Sparkles } from "lucide-react";
import { BrowserRouter as Router, Routes, Route, useNavigate } from "react-router-dom";
import { Card, CardContent } from "@/components/ui/card";
import { motion } from "framer-motion";

function ExitIntegrationChamber() { /* ... existing code ... */ }

function InnerNarrativeRoom() { /* ... existing code ... */ }

function CellularMythopoesisChamber() { /* ... existing code ... */ }

function GoddessTouchUpsChamber() { /* ... existing code ... */ }

function SpaLayout({ children }) {
  return (
    <>
      <nav className="flex gap-4 justify-center p-4 bg-white shadow-md rounded-md mb-6">
        <a href="/" className="text-violet-700 hover:underline">Home</a>
        <a href="/chamber1" className="text-pink-700 hover:underline">Chamber 1</a>
        <a href="/chamber2" className="text-green-700 hover:underline">Chamber 2</a>
        <a href="/chamber3" className="text-fuchsia-700 hover:underline">Chamber 3</a>
        <a href="/exit" className="text-violet-900 hover:underline">Exit Chamber</a>
      </nav>
      <div className="min-h-screen bg-gradient-to-br from-indigo-100 to-rose-50 flex flex-col items-center justify-center p-10 space-y-10">
        {children}
      </div>
    </>
  );
}

function SpaWelcomePage() {
  return (
    <Card className="max-w-2xl w-full shadow-xl rounded-xl relative overflow-hidden">
      <CardContent className="p-6 space-y-6 text-center relative">
        <h1 className="text-3xl font-bold text-violet-800">Welcome to MythoMed Spa</h1>
        <p className="text-violet-900">
          A sanctuary where soul, symbol, and cellular harmony converge.
          Enter any chamber to recalibrate your myth and moisturize your meaning.
        </p>
        <motion.div
          className="text-violet-700 italic"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 2 }}
        >
          “Here, even your aura gets a facial.”
        </motion.div>
      </CardContent>
    </Card>
  );
}

export default function MythoMedSpa() {
  return (
    <Router>
      <SpaLayout>
        <Routes>
          <Route path="/" element={<SpaWelcomePage />} />
          <Route path="/chamber1" element={<InnerNarrativeRoom />} />
          <Route path="/chamber2" element={<CellularMythopoesisChamber />} />
          <Route path="/chamber3" element={<GoddessTouchUpsChamber />} />
          <Route path="/exit" element={<ExitIntegrationChamber />} />
        </Routes>
      </SpaLayout>
    </Router>
  );
}
